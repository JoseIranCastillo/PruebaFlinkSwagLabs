package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

import generalMetods.KeyWords;
import page.CheckoutInformationSwagLabs;
import page.CheckoutOverviewSwagLabs;
import page.FinishSwagLabs;
import page.Login;
import page.ProductsSwagLabs;
import page.YouCartSwagLabs;

public class EcomerceSwagLabs {
	
	public static WebDriver driver;
	
	ExtentHtmlReporter htmlRep;
    static ExtentReports report;
    static ExtentTest resulTest;
    
   
    @BeforeTest
    public void startReport() {
    	
    	htmlRep = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/testReport.html");
         
        report = new ExtentReports();
        report.attachReporter(htmlRep);
        htmlRep.config().setChartVisibilityOnOpen(true);
        htmlRep.config().setDocumentTitle("Extent Report Demo");
        htmlRep.config().setReportName("Test Report");
        htmlRep.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlRep.config().setTheme(Theme.STANDARD);
        
    }
	

	@Test(priority=0)
	public static void login() throws InterruptedException{
		resulTest = report.createTest("login", "Test Case 1");
		Thread.sleep(3000);
		KeyWords.capturarDataPorId(Login.sUserNameTxtID, "standard_user");
		KeyWords.capturarDataPorId(Login.sPasswordTxtID, "secret_sauce");
		KeyWords.clickPorId(Login.sLoginButtonID);
		Thread.sleep(10000);
	}
	@Test(priority=1)
	public static void prodSwagLabs() throws InterruptedException{
		resulTest = report.createTest("prodSwagLabs", "Test Case 2");
		KeyWords.clickPorXpath(ProductsSwagLabs.sBackpackXpath);
		KeyWords.clickPorXpath(ProductsSwagLabs.sFleeceJacketXpath);
		Thread.sleep(3000);
		KeyWords.clickPorXpath(ProductsSwagLabs.sCarritoXpath);
		Thread.sleep(2000);
		}

	@Test(priority=2)
	public static void youCartSwag() throws InterruptedException{
			resulTest = report.createTest("youCartSwag", "Test Case 3");
		String sDescripcionProd = driver.findElement(By.xpath(YouCartSwagLabs.sNombreProd1Xpath)).getText();
		String sNombreProdExpec = "Sauce Labs Backpack";
		Assert.assertEquals(sDescripcionProd, sNombreProdExpec);
		sDescripcionProd = driver.findElement(By.xpath(YouCartSwagLabs.sNombreProd2Xpath)).getText();
		sNombreProdExpec = "Sauce Labs Fleece Jacket";
		Assert.assertEquals(sDescripcionProd, sNombreProdExpec);
		KeyWords.clickPorXpath(YouCartSwagLabs.sRemover2Xpath);
		Thread.sleep(2000);
		KeyWords.clickPorXpath(YouCartSwagLabs.sCheckoutButtonXpath);
		Thread.sleep(1500);
		
		}

		
	@Test(priority=3)
	public static void checkoutInformation() throws InterruptedException{
			resulTest = report.createTest("checkoutInformation", "Test Case 4");
		KeyWords.capturarDataPorId(CheckoutInformationSwagLabs.sFirstNameID, "Jos� Ir�n");
		KeyWords.capturarDataPorId(CheckoutInformationSwagLabs.sLastNameID, "Castillo");
		KeyWords.clickPorXpath(CheckoutInformationSwagLabs.sContinueXpath);
		String sDescripcionError = driver.findElement(By.xpath(CheckoutInformationSwagLabs.sErrorXpath)).getText();
		String sNombreErrorExpec = "Error: Postal Code is required";
		Assert.assertEquals(sDescripcionError, sNombreErrorExpec);
		Thread.sleep(3000);
		KeyWords.capturarDataPorId(CheckoutInformationSwagLabs.sPostalCodeID, "80197");
		KeyWords.clickPorXpath(CheckoutInformationSwagLabs.sContinueXpath);
		Thread.sleep(1500);
		}
		
		
	@Test(priority=4)
	public static void checkoutOverview() throws InterruptedException{
			resulTest = report.createTest("checkoutOverview", "Test Case 5");
		KeyWords.clickPorXpath(CheckoutOverviewSwagLabs.sFinisXpath);
		
		}
		
	@Test(priority=5)
	public static void finishSwagLabs() throws InterruptedException{
			resulTest = report.createTest("finishSwagLabs", "Test Case 5");
		String sDescTankYou = driver.findElement(By.xpath(FinishSwagLabs.sTankYuoXpath)).getText();
		String sTankYouExpec = "THANK YOU FOR YOUR ORDER";
		Assert.assertEquals(sDescTankYou, sTankYouExpec);
		Thread.sleep(3000);
		
	}
	
	

	@BeforeTest
	public static void beforeTest() {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
		KeyWords.driver = driver;

	}

		
	
	@AfterMethod
    public void getResult(ITestResult result) {
        if(result.getStatus() == ITestResult.FAILURE) {
            resulTest.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            resulTest.fail(result.getThrowable());
        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
            resulTest.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
        }
        else {
            resulTest.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
            resulTest.skip(result.getThrowable());
        }
    }

	@AfterTest
	public static void afterTest() {
		driver.close();
		driver.quit();
		KeyWords.driver.quit();
		report.flush();
	}

}
