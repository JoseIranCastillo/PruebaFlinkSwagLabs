package generalMetods;

import java.util.NoSuchElementException;
import test.EcomerceSwagLabs;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


public class KeyWords {
	
public static WebDriver driver;
	
	public static void capturarDataPorId(String strLocalizador, String strDatoEntrada) {
		
		try {
			WebElement txtObjeto;
			//Verificar si existe
			txtObjeto = driver.findElement(By.id(strLocalizador));
			//verificar si esta disponible 
			if (!(txtObjeto.isDisplayed() && txtObjeto.isEnabled())) {
				System.out.println("Elemento no desplegado o disponible");
				
			}
			//Aplicar accion
			txtObjeto.sendKeys(strDatoEntrada);
			//EcomerceSwagLabs.testResult.log(Status.PASS, MarkupHelper.createLabel(" PASSED ", ExtentColor.GREEN));
			//EcomerceSwagLabs.testResult.log(LogStatus.PASS, "capturarDataPorId", "Dato capturado correctamente");
			
		}
		catch(Exception e) {
			System.out.println("Error en la captura de datos "+ e.getMessage());
			//EcomerceSwagLabs.testResult.log(Status.FAIL, MarkupHelper.createLabel("Fail", ExtentColor.RED),e.getMessage());
			//createLabel(result.getName()+" FAILED ", ExtentColor.RED));
			}
	}
	
public static void capturarDataPorXpath(String strLocalizador, String strDatoEntrada) {
		
		try {
			WebElement txtObjeto;
			//Verificar si existe
			txtObjeto = driver.findElement(By.xpath(strLocalizador));
			//verificar si esta disponible 
			if (!(txtObjeto.isDisplayed() && txtObjeto.isEnabled())) {
				System.out.println("Elemento no desplegado o disponible");
				
			}
			//Aplicar accion
			txtObjeto.sendKeys(strDatoEntrada);
			//EcomerceSwagLabs.testResult.log(Status.PASS, MarkupHelper.createLabel(" PASSED ", ExtentColor.GREEN));
			//EcomerceSwagLabs.testResult.log(LogStatus.PASS, "capturarDataPorXpath", "Dato capturado correctamente");			
		}
		catch(Exception e) {
			System.out.println("Error en la captura de datos "+ e.getMessage());
			//EcomerceSwagLabs.testResult.log(Status.FAIL, MarkupHelper.createLabel("Fail", ExtentColor.RED));
			//EcomerceSwagLabs.testResult.log(LogStatus.FATAL, "capturarDataPorXpath", e.getMessage());
		}
	}
	
public static void clickPorId (String strLocalizador) {
		
		try {
			WebElement txtObjeto;
			//Verificar si existe
			txtObjeto = driver.findElement(By.id(strLocalizador));
			//verificar si esta disponible 
			if (!(txtObjeto.isDisplayed() && txtObjeto.isEnabled())) {
				System.out.println("Elemento no desplegado o disponible");
				
			}
			//Aplicar accion
			txtObjeto.click();;
			//EcomerceSwagLabs.testResult.log(Status.PASS, MarkupHelper.createLabel(" PASSED ", ExtentColor.GREEN));
			//EcomerceSwagLabs.testResult.log(LogStatus.PASS, "clickPorId", "Se dio clic al objeto");
			
		}
		catch(Exception e) {
			System.out.println("Error en la captura de datos "+ e.getMessage());
			//EcomerceSwagLabs.testResult.log(Status.FAIL, MarkupHelper.createLabel("Fail", ExtentColor.RED));
			//EcomerceSwagLabs.testResult.log(LogStatus.FATAL, "clickPorId", e.getMessage());
		}
	}

public static void clickPorXpath(String strLocalizador) {
	
	try {
		WebElement txtObjeto;
		//Verificar si existe
		txtObjeto = driver.findElement(By.xpath(strLocalizador));
		//verificar si esta disponible 
		if (!(txtObjeto.isDisplayed() && txtObjeto.isEnabled())) {
			System.out.println("Elemento no desplegado o disponible");
			
		}
		//Aplicar accion
		txtObjeto.click();;
		//EcomerceSwagLabs.testResult.log(Status.PASS, MarkupHelper.createLabel(" PASSED ", ExtentColor.GREEN));
		//EcomerceSwagLabs.testResult.log(LogStatus.PASS, "clickPorXpath", "Se dio clic al objeto");
		
	}
	catch(Exception e) {
		System.out.println("Error en la captura de datos "+ e.getMessage());
		//EcomerceSwagLabs.testResult.log(Status.FAIL, MarkupHelper.createLabel("Fail", ExtentColor.RED));
		//EcomerceSwagLabs.testResult.log(LogStatus.FATAL, "clickPorXpath", e.getMessage());
		
	}
}
	
}
