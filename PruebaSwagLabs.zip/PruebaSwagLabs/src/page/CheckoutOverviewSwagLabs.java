package page;

public class CheckoutOverviewSwagLabs {
	
	public static String sFinisXpath = "//div[@class='cart_footer']/a[@class='btn_action cart_button']";


}
