package page;

public class ProductsSwagLabs {
	
	public static String sBackpackXpath = "//*[text()='Sauce Labs Backpack']/following::button[@class='btn_primary btn_inventory'][1]";
	public static String sFleeceJacketXpath = "//*[text()='Sauce Labs Fleece Jacket']/following::button[@class='btn_primary btn_inventory'][1]";
	public static String sCarritoXpath = "//span[@class='fa-layers-counter shopping_cart_badge']";
	public static String sImagenXpath = "//a[@id='item_3_img_link']/img[@class='inventory_item_img']/@src";
}
