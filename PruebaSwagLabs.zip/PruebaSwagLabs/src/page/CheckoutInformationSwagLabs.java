package page;

public class CheckoutInformationSwagLabs {
	
	public static String sFirstNameID = "first-name";
	public static String sLastNameID = "last-name";
	public static String sPostalCodeID = "postal-code";
	public static String sErrorXpath = "//div[@class='checkout_info_wrapper']/form/h3";
	public static String sContinueXpath = "//div[@class='checkout_buttons']/input[@class='btn_primary cart_button']";
	

}
