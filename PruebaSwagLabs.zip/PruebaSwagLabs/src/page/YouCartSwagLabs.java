package page;

public class YouCartSwagLabs {
	
	public static String sNombreProd1Xpath = "//div[@class='cart_desc_label']/following::div[@class='inventory_item_name'][1]";
	public static String sNombreProd2Xpath = "//div[@class='cart_desc_label']/following::div[@class='inventory_item_name'][2]";
	public static String sRemover2Xpath = "//div[@class='cart_desc_label']/following::button[@class='btn_secondary cart_button'][2]";
	public static String sCheckoutButtonXpath = "//a[@class='btn_action checkout_button']";

}
