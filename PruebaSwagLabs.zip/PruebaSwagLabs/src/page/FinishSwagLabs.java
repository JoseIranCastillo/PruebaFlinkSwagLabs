package page;

public class FinishSwagLabs {
	
	public static String sTankYuoXpath = "//div[@id='checkout_complete_container']/h2[@class='complete-header']";

}
