package page;

public class Login {
	
	public static String sUserNameTxtID = "user-name";
	public static String sPasswordTxtID = "password";
	public static String sLoginButtonID = "login-button";
	

}
